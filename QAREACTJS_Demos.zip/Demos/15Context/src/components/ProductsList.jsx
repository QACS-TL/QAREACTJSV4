import Product from './Product'
import itemsData from '../itemsData.json'

export default function ProductsList() {
  return (
    <div>
      <h2>Products</h2>
      <div className="items-grid">
        {itemsData.map((item) => (
          <Product
            key={item.id}
            id={item.id}
            symbol={item.symbol}
            name={item.name}
            price={item.price}
          />
        ))}
      </div>
    </div>
  )
}
