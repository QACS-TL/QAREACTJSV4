import CartList from './components/CartList'
import ProductsList from './components/ProductsList'
import { CartProvider } from './context/cart-context'
import './style.css'

export default function App() {
  return (
    <main>
      <h1>React Fruit Market</h1>
      <CartProvider>
        <CartList />
        <ProductsList />
      </CartProvider>
    </main>
  )
}