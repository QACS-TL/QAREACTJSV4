const Data = (props) => {
    return (
        <div>
             <p>This is {props.item.firstName} {props.item.lastName}, they are from {props.item.country}</p>
        </div>
    )
}

export default Data