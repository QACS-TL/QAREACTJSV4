import './App.css'
import someData from './someData.json';
import Data from './Data';

function App() {
  const allData = someData.users.map(data =>
    <Data item={data} key={data.id} />);

    return (
      <>
        <h2>The data supplied is:</h2>
        <div>
          {allData}
        </div>

        <h2>The data supplied is:</h2>
        <div>
          { someData.users.map(data =>(
            <p key={data.id.toString()}>This is {data.firstName}  {data.lastName}, they are from {data.country}</p>
          ))}
        </div>
      </>
    );
}

export default App
