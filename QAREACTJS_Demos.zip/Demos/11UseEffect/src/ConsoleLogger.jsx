import {useState, useEffect} from 'react'

function ConsoleLogger() {
    const [count, setCount] = useState(0)
    const [isLoggingOn, setIsLoggingOn] = useState(true)

    useEffect(() => {
        // This should run whenever "count" changes.
        if (isLoggingOn) {
          console.log( count )
        }
      }, [count, isLoggingOn])

    return(
        <div>
          <h1>Console Logger</h1>
    
          <button onClick={() => setIsLoggingOn((prev) => !prev)}>
            Logging: {isLoggingOn ? 'on' : 'off'}
          </button>
    
          <h2>{count}</h2>
    
          <button onClick={() => setCount((previous) => previous + 1)}>+1</button>
          <button onClick={() => setCount(0)}>Reset</button>
        </div>
      );
    }
    
export default ConsoleLogger;