import { useState } from "react";
const Create = () => {

    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [title, setTitle] = useState('Mx');

    // const handleSubmit = (e) => {
    //     e.preventDefault();
    //     const user = { firstName: firstName, lastName: lastName, title }

    //     fetch('http://localhost:8000/users', {
    //         method: 'POST',
    //     headers:     { "Content-Type": "application/json" },
    //         body: JSON.stringify(user)
    //     })

    //     setFirstName('');
    //     setLastName('');
    //     setTitle('');
    // }

    const handleSubmit = async (e) => {
        e.preventDefault();
        const user = { firstName: firstName, lastName: lastName, title }

        await fetch('http://localhost:8000/users', {
          method: 'POST',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(user)
        })

        setFirstName('');
        setLastName('');
        setTitle('');
      }

    
    return ( 
        <form onSubmit={handleSubmit}>
            <label>First Name:</label>
            <input type="text" 
             required
             value={firstName}
             onChange={(e) => setFirstName(e.target.value)}
            />
            <br />
            <label>Last Name:</label>
            <input type="text" 
             required
             value={lastName}
             onChange={(e) => setLastName(e.target.value)}
            />
            <br />
            <label>Title:</label>
            <select 
            value={title}
            onChange={(e) => setTitle(e.target.value)}>
                <option value="Mr">Mr</option>
                <option value="Mrs">Mrs</option>
                <option value="Ms">Ms</option>
                <option value="Miss">Miss</option>
                <option value="Mx">Mx</option>
                <option value="Dr">Dr</option>
                <option value="HRH">HRH</option>
            </select>
            <br />
            <button>Add User</button>
        </form>
     );

    }
export default Create;