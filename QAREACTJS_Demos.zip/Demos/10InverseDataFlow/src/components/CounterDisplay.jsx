

export default function CounterDisplay({ count }) {
    return <h1>{count}</h1>
  }
  