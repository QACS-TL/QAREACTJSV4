import { Link, NavLink } from 'react-router-dom'

export default function Navbar() {
    return (
        <nav>
            <h1>React App</h1>
            <ul>
                <li>
                    <Link to="/">Home</Link>
                </li>
                <li>
                    <NavLink to="/about" className={({isActive}) => isActive?"active":"inactive"} >About</NavLink>
                </li>
            </ul>
        </nav>
    )
}

