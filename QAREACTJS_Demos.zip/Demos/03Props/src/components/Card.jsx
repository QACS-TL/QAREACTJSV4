import ailogo from "../assets/AILogo.png"
// const Card = ({name,age,role, isActive}) => {
const Card = (props) => {   
    return ( 
        <div className="card">
            <img src={ailogo}
                width="100px"
                alt="" 
            />
            <h1>{props.name} {props.isActive && '🏵'}</h1> 
            <h2>{props.age}</h2>
            <h2>{props.role}</h2>
        </div> 
    );
}
 
export default Card;