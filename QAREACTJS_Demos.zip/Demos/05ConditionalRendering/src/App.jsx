import Card from './components/Card';
import './App.css';

function App() {
    return (
    <div className="App">
      <p><Card name="Bill" age="35" role="Catering" isActive={true}/></p>
      <p><Card name="Mary" age="27" role="Sales" isActive={false}/></p>
      <p><Card name="Sadia" age="43" role="DevOps" isActive={true}/></p>
    </div>
  
  );
}

export default App;


