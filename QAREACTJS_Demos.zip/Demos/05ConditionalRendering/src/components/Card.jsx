
// const Card = ({name,age,role, isActive}) => {
//     return ( 
//         <div className="card">
//             <img src="../../public/PersonSilhouette.jpg" 
//                 width="100px"
//                 alt="" 
//             />
//             <h1>{name}</h1>
//             <h2>Active:{isActive && "✅"}</h2>
//             <h2>{age}</h2>
//             <h2>{role}</h2>
//         </div> 
//     );
// }
// 
// export default Card;


// const Card = ({name,age,role, isActive}) => {
//     return ( 
//         <div className="card">
//             <img src="../../public/PersonSilhouette.jpg" 
//                 width="100px"
//                 alt="" 
//             />
//             <h1>{name}</h1>
//             <h2>Active:{isActive?"✅":"❌"}</h2>
//             <h2>{age}</h2>
//             <h2>{role}</h2>
//         </div> 
//     );
// }
// 
//export default Card;

const Card = ({name,age,role, isActive}) => {
    if (isActive){
        return ( 
            <div className="card">
                <img src="../../public/PersonSilhouette.jpg" 
                    width="100px"
                    alt="" 
                />
                <h1>{name}</h1>
                <h2>Active:✅</h2>
                <h2>{age}</h2>
                <h2>{role}</h2>
            </div> 
        );
    } else {
        return ( 
            <div className="card">
                <img src="../../public/PersonSilhouette.jpg" 
                    width="100px"
                    alt="" 
                />
                <h1>{name}</h1>
                <h2>Active:❌</h2>
                <h2>{age}</h2>
                <h2>{role}</h2>
            </div> 
        );
    }
}
 
export default Card;