

function BookCard({ title, author, publisher}) {
    return (
        <div className="item-card">
            <div className="symbol">{title}</div>
            <h3>{author}</h3>
            <p>{publisher}</p>
        </div>
    )
}
export default BookCard;