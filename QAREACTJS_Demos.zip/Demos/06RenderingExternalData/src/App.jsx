import ItemCard from './components/ItemCard';
import fruitData from './fruitData.json';
import BookCard from './components/BookCard';
import './App.css';

function App() {
  const books = [
    {title: 'Rebel the Pebble', author: 'J R Hartley', publisher: 'We Do Books inc.', id:1},
    {title: 'Janet the Planet', author: 'Venus de Milo', publisher: 'Cosmos', id:2},
    {title: 'Kat the Bat', author: 'Chiro Vespertilio', publisher: 'Fauna Press', id:3}
  ]
  return (
    <div className="App">
      <h1>Books</h1>
        <div className="items-grid">
          {books.map((bk) => (
            <div className="item-card" key={bk.id}>
                <div className="symbol">{bk.title}</div>
                <h3>{bk.author}</h3>
                <p>{bk.publisher}</p>
            </div>
      ))}
      </div>
      <h1>Books</h1>
        <div className="items-grid">
          {books.map((book) => (
            <BookCard 
            key={book.id}
            title={book.title}
            author={book.author}
            publisher={book.publisher}
            />
          ))}
        </div>
        <h1>React Fruit Market</h1>
        <div className="items-grid">
          {fruitData.map((item) => (
            <ItemCard 
            key={item.id}
            symbol={item.symbol}
            name={item.name}
            price={item.price}
            />
          ))}
        </div>
    </div>
  
  );
}

export default App;


