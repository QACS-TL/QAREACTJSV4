function AdminPage() {
    return (
      <div>
        <h2>Admin Page</h2>
        <p>Welcome to the admin page!</p>
      </div>
    );
  }

  export default AdminPage;