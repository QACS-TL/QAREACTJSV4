import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import AuthButton from './AuthButton.jsx';
import Home from './Home.jsx';
import About from './About.jsx';
import LoginForm from'./LoginForm.jsx';
import PrivateRoute from './PrivateRoute.jsx';
import AdminPage from './AdminPage.jsx';
import { AuthContext } from './AuthContext .jsx';

function App() {

    const [loggedIn, setLoggedIn] = useState(() => {
      return JSON.parse(sessionStorage.getItem('loggedIn')) || false;
    });
  
    const handleLogin = () => { // Added handleLogin function
      setLoggedIn(true);
    };
  
    const handleLogout = () => {
      setLoggedIn(false);
    };
  
    useEffect(() => {
      sessionStorage.setItem('loggedIn', JSON.stringify(loggedIn));
    }, [loggedIn]);
  
    return (
      <>
      <h1>App Using Just Session Storage and context</h1>
      <AuthContext.Provider value={{ loggedIn, handleLogin, handleLogout }}> {/* Added handleLogin to the context */}
        <Router>
          <div>
            <nav>
              <ul>
                <li>
                  <Link to="/">Home</Link>
                </li>
                <li>
                  <Link to="/about">About</Link>
                </li>
                <li>
                  <AuthButton />
                </li>
              </ul>
            </nav>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/login" element={<LoginForm />} />
              <Route path="/admin" element={<PrivateRoute component={<AdminPage />} />} />
            </Routes>
          </div>
        </Router>
      </AuthContext.Provider>
      </>
    );
  }

  export default App;