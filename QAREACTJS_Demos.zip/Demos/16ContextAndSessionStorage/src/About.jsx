import { Link } from "react-router-dom";

function About() {
    return (
      <div>
        <h1>About Us</h1>
        <Link to="/">Go back to Home</Link>
      </div>
    );
}

export default About