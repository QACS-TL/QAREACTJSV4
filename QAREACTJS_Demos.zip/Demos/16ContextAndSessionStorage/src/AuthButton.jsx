import { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from './AuthContext ';

function AuthButton() {
    const { loggedIn, handleLogout } = useContext(AuthContext);
  
    return loggedIn ? <button onClick={handleLogout}>Logout</button> : <Link to="/login">Login</Link>;
}

export default AuthButton;