import { useContext } from 'react';
import { AuthContext } from './AuthContext ';

function LoginForm() {
    const { handleLogin } = useContext(AuthContext);
  
    const handleLoginClick = () => {
      // Simulating login logic
      handleLogin();
    };
  
    return (
      <div>
        <h2>Login</h2>
        <button onClick={handleLoginClick}>Login</button>
      </div>
    );
  }

  export default LoginForm;