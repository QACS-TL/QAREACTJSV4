import { useState } from 'react';

const MyForm = () => {
  const [name, setName] = useState(``);
  return(
    <form>

        <input
            type="text"
            name="name"
            value={name}
            onChange={event =>
                setName(event.target.value)} />
        <label>
            {name}
        </label>
    </form>

  );
 };
 export default MyForm;
// The output of the input is now
// controlled by React