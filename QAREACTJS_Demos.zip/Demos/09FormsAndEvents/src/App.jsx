import { useState } from 'react';
import "./App.css";
import MyForm from './MyForm';

const App = () => {
  const [count, setCount] = useState(0);
  const [currClass, setCurrClass] = useState(`green`);
  const changeClass = e => {
    if(e.type === `mouseenter`) setCurrClass(`red`);
    if(e.type === `mouseleave`) setCurrClass(`blue`);
  };

  return(
    <div>
        <p>Count is: {count}</p>
        <button onClick={() => setCount(count + 1)}>+</button>
         onClick event triggers callback and a re-render
        <p onMouseEnter={e => changeClass(e)}
          onMouseLeave={e => changeClass(e)}
          className={currClass}>
          Move the mouse over this text to change colour</p>
        <p>
         onMouseEnter and onMouseLeave calls the changeClass
         function, passing the event as an argument and
         setting the value of currClass causing a re-render
         </p>
         <MyForm />
    </div>
  );
}
 export default App;

