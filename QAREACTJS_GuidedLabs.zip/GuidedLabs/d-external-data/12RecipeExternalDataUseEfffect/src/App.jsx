import { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';
import 'popper.js';
import 'jquery';
import './Components/css/qa.css';
import sampleRecipes from './samplerecipes.json';
import Header from './Components/Header';
import Footer from './Components/Footer';
import AllRecipes from './Components/AllRecipes';
import AddEditRecipe from './Components/AddEditRecipe';

function App() {
  const [recipes, setRecipes] = useState({});
 
  useEffect(() => {	
      setRecipes({recipes: sampleRecipes.recipes});
  });	
  

  const submitRecipe = recipe => {
    const updatedRecipes = [...recipes.recipes, recipe];
    setRecipes({recipes: updatedRecipes});	
  }
  
  return (
    <>
      <div className="container">
        <Header />
        <div className="container">
          <AllRecipes data={recipes} />
          <AddEditRecipe submitRecipe={submitRecipe} />
        </div>
        <Footer />
      </div>
    </>
  );
}

export default App;
