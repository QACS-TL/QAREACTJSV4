import  { useState, useEffect } from "react";

const DateAdded = ({ updateDateAdded }) => {
  const [date, setDate] = useState((new Date()).toLocaleDateString());
  useEffect(() => {
    const interval = setInterval(() => {
      setDate((new Date()).toLocaleDateString());
    }, 60000);

    return () => clearInterval(interval);
  });

  useEffect(() => {
    updateDateAdded(date);
  }, [updateDateAdded, date]);

  return (
    <span data-testid="dateAdded">
      {/* &nbsp;{`${date.toLocaleDateString()} @ ${date.toLocaleTimeString()}`} */}
      &nbsp;{date}
    </span>
  );
};

DateAdded.defaultProps = {
  updateDateAdded: () => null,
  dateAdded: (new Date()).toLocaleDateString()
}

export default DateAdded;
