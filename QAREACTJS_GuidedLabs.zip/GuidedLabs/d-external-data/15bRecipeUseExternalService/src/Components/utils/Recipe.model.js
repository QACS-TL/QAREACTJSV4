export default class RecipeModel {
  constructor(id, title, ingredients, instructions, dateAdded, tested) {
    this.id = id;
    this.title = title;
    this.ingredients = ingredients;
    this.instructions = instructions;
    this.dateAdded = dateAdded
    this.tested = tested;
  }
}
