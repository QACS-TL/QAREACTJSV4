import './css/AddEditRecipe.css';
import RecipeForm from './RecipeForm';
import RecipeModel from './utils/Recipe.model';

const AddEditRecipe = props => {

    const submitRecipe = (title, ingredients, instructions, dateAdded, tested) => {
        const recipeToSubmit = new RecipeModel('', title, ingredients, instructions, dateAdded, tested);
        props.submitRecipe(recipeToSubmit);
    }

    const updateRecipe = (title, ingredients, instructions, dateAdded, tested, id) => {
        const updatedRecipe = new RecipeModel(id, title, ingredients, instructions, dateAdded, tested);
        props.updateRecipe(updatedRecipe);
    }

    const submitAction = props.recipe ? updateRecipe : submitRecipe;
    
    return (
        <>
            <div className="addEditRecipe row">
                <h3>{props.recipe ? `Edit` : `Add`} Recipe</h3>
            </div>
            <RecipeForm submitAction={submitAction} recipe={props.recipe} />
        </>
    );
}

export default AddEditRecipe;
