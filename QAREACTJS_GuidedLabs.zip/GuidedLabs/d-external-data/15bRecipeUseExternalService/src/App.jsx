import { useState, useEffect } from 'react';
//import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';
import 'popper.js';
import 'jquery';
import './Components/css/qa.css';
//import axios from 'axios';
import Header from './Components/Header';
import Footer from './Components/Footer';
import AllRecipes from './Components/AllRecipes';
import AddEditRecipe from './Components/AddEditRecipe';
import Modal from './Components/utils/Modal';

const RECIPESURL = `http://localhost:4000/recipes`;

function App() {
  const [recipes, setRecipes] = useState({});
  const [recipeToEdit, setRecipeToEdit] = useState(null);
  const [onlineStatus, setOnlineStatus] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {	
    //setTimeout(() => {
      getRecipes();
    //}, 5000)
  }, []);	
  
  const getRecipes = async () => {
    try {
      const response = await fetch(RECIPESURL);
  
      const recipes_from_db = await response.json();
      setRecipes(recipes_from_db);
      setLoading(false);
      setOnlineStatus(true);
    } catch (error) {
      setRecipes(error.message);
      setLoading(false);
      setOnlineStatus(false);
    }
  };

  const postRecipe = async (recipe) => {
    try {
      const response = await fetch(RECIPESURL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(recipe),
      });
  
      setOnlineStatus(true);
      getRecipes();
    } catch (error) {
      setRecipes(error.message);
      setOnlineStatus(false);
    }
  };
  
  const submitRecipe = recipe => {
    postRecipe(recipe);	
  }
  
  const selectRecipe = recipe => {
    setRecipeToEdit(recipe);
  }

  const updateRecipe = recipe => {
    putRecipe(recipe);
  }

  const putRecipe = async (recipe) => {
    try {
      const response = await fetch(`${RECIPESURL}/${recipe.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(recipe),
      });
      setRecipeToEdit(null)
      setOnlineStatus(true);
      getRecipes();
    } catch (error) {
      setRecipes(error.message);
      setOnlineStatus(false);
    }
  };
  
  return (
    <>
     <div className="container">
        <Header />
        <div className="container">
          {!onlineStatus && !loading ? (
            <h3>The data server may be offline, changes will not be saved</h3>
          ) : null}
              <AllRecipes loading={loading}  recipes={recipes} selectRecipe={selectRecipe}/>
              <AddEditRecipe  submitRecipe={submitRecipe} updateRecipe={updateRecipe} recipe={recipeToEdit} />
        </div>
        <Footer />
      </div>
    </>
  );
}

export default App;
