import  { useState } from 'react';
import DateAdded from './utils/DateAdded';

const RecipeForm = ({ submitRecipe }) => {

    const [title, setTitle] = useState(``);
    const [ingredients, setIngredients] = useState(``);
    const [instructions, setInstructions] = useState(``);
    const [dateAdded, setDateAdded] = useState(``);
    const [tested, setTested] = useState(undefined);

    const handleSubmit = event => {
        event.preventDefault();
        let tested_val = false;
        if (tested === true) tested_val = true;
        submitRecipe(title, ingredients, instructions, dateAdded, tested_val );          setTitle(``);
        setIngredients(``);
        setInstructions(``);
        setDateAdded(``);
        setTested(undefined);
    }

    return (
        <form onSubmit={handleSubmit}>
            <div className="form-group">
                <label htmlFor="recipeTitle">Title:&nbsp;</label>
                <input
                    type="text"
                    name="recipeTitle"
                    placeholder="Recipe Title"
                    className="form-control"
                    value={title}
                    onChange={event => setTitle(event.target.value)}
                />
            </div>
            <div className="form-group">
                <label htmlFor="recipeIngredients">Ingredients:&nbsp;</label>
                <input
                    type="text"
                    name="recipeIngredients"
                    placeholder="Recipe Ingredients"
                    className="form-control"
                    value={ingredients}
                    onChange={event => setIngredients(event.target.value)}
                />
            </div>  
            <div className="form-group">
                <label htmlFor="recipeInstructions">Instructions:&nbsp;</label>
                <input
                    type="text"
                    name="recipeInstructions"
                    placeholder="Recipe Instructions"
                    className="form-control"
                    value={instructions}
                    onChange={event => setInstructions(event.target.value)}
                />
            </div>            
            <div className="form-group">
                <label htmlFor="recipeDateAdded">DateAdded:&nbsp;</label>
                <DateAdded updateDateAdded={dateAdded => setDateAdded(dateAdded)} />
            </div>
            <div className="form-group">
                <label htmlFor="recipeTested">Tested:&nbsp;</label>
                <input
                    type="checkbox"
                    name="recipeTested"
                    checked={tested}
                    value={tested}
                    onChange={event => setTested(event.target.checked)}
                />
            </div>
            <div className="form-group">
                <input type="submit" value="Submit" className={`btn ${!title ? `btn-danger` : `btn-primary`}`} disabled={!title} />
            </div>
        </form>
    );
};

export default RecipeForm;
