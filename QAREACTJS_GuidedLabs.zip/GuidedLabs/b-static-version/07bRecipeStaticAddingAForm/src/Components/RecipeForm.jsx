import DateAdded from './utils/DateAdded';

const RecipeForm = () => {
    return (
        <form>
            <div className="form-group">
                <label htmlFor="recipeTitle">Title:&nbsp;</label>
                <input
                    type="text"
                    name="recipeTitle"
                    placeholder="Recipe Title"
                    className="form-control"
                />
            </div>
            <div className="form-group">
                <label htmlFor="recipeIngredients">Ingredients:&nbsp;</label>
                <input
                    type="text"
                    name="recipeIngredients"
                    placeholder="Recipe Ingredients"
                    className="form-control"
                />
            </div>  
            <div className="form-group">
                <label htmlFor="recipeInstructions">Instructions:&nbsp;</label>
                <input
                    type="text"
                    name="recipeInstructions"
                    placeholder="Recipe Instructions"
                    className="form-control"
                />
            </div>            
            <div className="form-group">
                <label htmlFor="recipeDateAdded">DateAdded:&nbsp;</label>
                <DateAdded  />
            </div>
            <div className="form-group">
                <label htmlFor="recipeTested">Tested:&nbsp;</label>
                <input
                    type="checkbox"
                    name="recipeTested"
                />
            </div>
            <div className="form-group">
                <input type="submit" value="Submit" className="btn-primary" />
            </div>
        </form>
    );
};

export default RecipeForm;
