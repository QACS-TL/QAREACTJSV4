import './css/AddEditRecipe.css';
import RecipeForm from './RecipeForm';

const AddEditRecipe = () => {
    return (
        <>
            <div className="addEditRecipe row">
                <h3>Add/Edit Recipe</h3>
            </div>
            <RecipeForm />
        </>
    );
}

export default AddEditRecipe;
