const Footer = () => {
  return (
    <footer className="mt-auto py-3 container text-center">
      &copy; QA Ltd 2019-
    </footer>
  );
};

export default Footer;
