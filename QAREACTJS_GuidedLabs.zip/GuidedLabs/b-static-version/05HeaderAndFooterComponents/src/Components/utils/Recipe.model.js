export default class RecipeModel {
  constructor(title, ingredients, instructions, dateAdded, tested, id) {
    this.title = title;
    this.ingredients = ingredients;
    this.instructions = instructions;
    this.dateAdded = dateAdded
    this.tested = tested;
    this.id = id;
  }
}
