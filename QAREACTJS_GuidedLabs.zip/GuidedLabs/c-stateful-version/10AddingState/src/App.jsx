import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';
import 'popper.js';
import 'jquery';
import './Components/css/qa.css';
import sampleRecipes from './samplerecipes.json';
import Header from './Components/Header';
import Footer from './Components/Footer';
import AllRecipes from './Components/AllRecipes';
import AddEditRecipe from './Components/AddEditRecipe';

function App() {
  const [recipes, setRecipes] = useState(sampleRecipes.recipes);

  return (
    <>
      <div className="container">
        <Header />
        <div className="container">
          <AllRecipes recipes={recipes} />
          <AddEditRecipe />
        </div>
        <Footer />
      </div>
    </>
  );
}

export default App;
