import './css/AddEditRecipe.css';
import RecipeForm from './RecipeForm';
import RecipeModel from './utils/Recipe.model';


const AddEditRecipe = props => {
    const submitRecipe = (title, ingredients, instructions, dateAdded, tested) => {
        const newRecipe = new RecipeModel(title, ingredients, instructions, dateAdded, tested, 0);
        props.submitRecipe(newRecipe);
    }
    
    return (
        <>
            <div className="addEditRecipe row">
                <h3>Add/Edit Recipe</h3>
            </div>
            <RecipeForm submitRecipe={submitRecipe} />
        </>
    );
}

export default AddEditRecipe;
