import './css/AllRecipes.css';
import Recipe from './Recipe';
import RecipeModel from './utils/Recipe.model';

const AllRecipes = ({data}) => {
  const recipes = data.recipes?.map(currentRecipe => {
      const recipe = new RecipeModel(
        currentRecipe.title, 
        currentRecipe.ingredients, 
        currentRecipe.instructions, 
        currentRecipe.dateAdded, 
        currentRecipe.tested,
        currentRecipe.id);
      return <Recipe recipe={recipe} key={recipe.id}  />
    });
  return (
    <div className="row">
      <h3>Recipes List</h3>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Title</th><th>Ingredients</th><th>Instructions</th><th>Date Added</th><th>Action</th>
          </tr>
        </thead>
        <tbody>{recipes}</tbody>
      </table>
    </div>
  );
};

export default AllRecipes;
