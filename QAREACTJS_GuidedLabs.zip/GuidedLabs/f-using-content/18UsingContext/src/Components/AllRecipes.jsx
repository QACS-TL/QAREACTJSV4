import { useRecipesState } from '../StateManagement/RecipesProvider';
import './css/AllRecipes.css';
import Recipe from './Recipe';
import RecipeModel from './utils/Recipe.model';

const AllRecipes = () => {
  const { recipes, loading, error } = useRecipesState();

  const renderRecipes = () => {
    return recipes.map(currentRecipe => {
      const recipe = new RecipeModel(
        currentRecipe.id,
        currentRecipe.title,
        currentRecipe.ingredients,
        currentRecipe.instructions,
        currentRecipe.dateAdded,
        currentRecipe.tested
      );
      return <Recipe recipe={recipe} key={recipe.id} />;
    });
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="row">
      <h3>Recipes List</h3>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Title</th>
            <th>Ingredients</th>
            <th>Instructions</th>
            <th>Date Added</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>{renderRecipes()}</tbody>
      </table>
    </div>
  );
};

export default AllRecipes;
