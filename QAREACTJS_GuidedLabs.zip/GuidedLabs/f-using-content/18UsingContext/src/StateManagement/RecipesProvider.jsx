import { createContext, useContext, useEffect, useState } from 'react';

const RecipesStateContext = createContext();
const baseUrl = `http://localhost:4000/recipes`;

const getAllRecipes = async () => {
  try {
    const response = await fetch(baseUrl);
    if (!response.ok) {
      throw new Error('Failed to fetch');
    }
    const data = await response.json();
    return data;
  } catch (error) {
    throw new Error(`Data not available from server: ${error.message}`);
  }
};

const RecipesProvider = ({ children }) => {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const getRecipes = async () => {
      try {
        const recipesData = await getAllRecipes();
        setRecipes(recipesData);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    getRecipes();
  }, []);

  return (
    <RecipesStateContext.Provider value={{ recipes, loading, error }}>
      {children}
    </RecipesStateContext.Provider>
  );
};

export const useRecipesState = () => {
  const context = useContext(RecipesStateContext);

  if (context === undefined) {
    throw new Error(`useRecipesState must be used within a RecipesProvider`);
  }

  return context;
};

export default RecipesProvider;
