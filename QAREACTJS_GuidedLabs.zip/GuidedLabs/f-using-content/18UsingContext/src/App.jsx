
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';
import 'popper.js';
import 'jquery';
import './Components/css/qa.css';
import Header from './Components/Header';
import Footer from './Components/Footer';
import AllRecipes from './Components/AllRecipes';
import AddEditRecipe from './Components/AddEditRecipe';
import NotFound from './Components/utils/NotFound';
import RecipesProvider from './StateManagement/RecipesProvider';

function App() {

  return (
    <Router>
      <div className="container">
        <Header />
        <div className="container">
          <RecipesProvider>
            <Routes>
                <Route exact path="/" element={<AllRecipes />} />
                <Route path="*" element={<NotFound />} />
            </Routes>
          </RecipesProvider>
        </div>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
