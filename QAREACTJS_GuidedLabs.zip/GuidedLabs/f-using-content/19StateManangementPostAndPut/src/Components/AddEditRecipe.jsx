import { useState, useEffect } from 'react';
import { useRecipesState } from '../StateManagement/RecipesProvider';
import './css/AddEditRecipe.css';
import RecipeForm from './RecipeForm';
import { useNavigate, useParams } from 'react-router-dom';
import Modal from './utils/Modal';

const AddEditRecipe = () => {
    const { recipes, addRecipe, updateRecipe } = useRecipesState();
    const [recipe, setRecipe] = useState(null);
    const { id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        if (id && recipes?.length !== undefined) {
            const recipeToEdit = recipes?.find(currentRecipe => currentRecipe.id == id);
            if (recipeToEdit) {
                setRecipe(recipeToEdit);
            } else {
                setRecipe({ error: `Recipe could not be found` });
            }
        }

        return () => {
            setRecipe(null);
        };
    }, [id, recipes]);

    const submitRecipe = async (title, ingredients, instructions, dateAdded, tested, id) => {
        try {
            if (id) {
                await updateRecipe(id,  {title, ingredients, instructions, dateAdded, tested });
            } else {
                await addRecipe({ title, ingredients, instructions, dateAdded, tested });
            }
            navigate('/'); // Redirect to the home page after submitting
        } catch (error) {
            console.error('Error:', error.message);
        }
    };

    const action = recipe ? `Edit` : `Add`;

    return (
        <>
            {recipe?.error && <Modal handleClose={() => setRecipe(null)} message={recipe.error} />}
            <div className="addEditRecipe row">
                <h3>{action} Recipe</h3>
            </div>
            <RecipeForm submitAction={submitRecipe} recipe={recipe} />
        </>
    );
};

export default AddEditRecipe;
