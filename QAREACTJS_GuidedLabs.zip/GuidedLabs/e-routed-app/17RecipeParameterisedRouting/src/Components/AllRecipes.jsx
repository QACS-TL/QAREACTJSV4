import './css/AllRecipes.css';
import Recipe from './Recipe';
import RecipeModel from './utils/Recipe.model';

const AllRecipes = props => {
  let recipes = [];
  if (props.recipes?.length && typeof props.recipes[0] !== "string") {
    recipes = props.recipes.map(currentRecipe => {
      const recipe = new RecipeModel(
        currentRecipe.id,
        currentRecipe.title, 
        currentRecipe.ingredients, 
        currentRecipe.instructions, 
        currentRecipe.dateAdded, 
        currentRecipe.tested);
      return <Recipe recipe={recipe} key={recipe.id} />
    });
  } else if (props.loading) {
    recipes.push(
      <tr key="loading">							
         <td colSpan="3">Please wait - retrieving the recipes</td>	
      </tr>
    );
  } else {	
    recipes.push(	
      <tr key="error">								
        <td colSpan="3">There has been an error retrieving the recipes</td>
      </tr>
    );
  }	
  return (
    <div className="row">
      <h3>Recipes List</h3>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Title</th><th>Ingredients</th><th>Instructions</th><th>Date Added</th><th>Action</th>
          </tr>
        </thead>
        <tbody>{recipes}</tbody>
      </table>
    </div>
  );
};
export default AllRecipes;
