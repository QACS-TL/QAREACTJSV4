import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import RecipeModel from './utils/Recipe.model';

const Recipe = ({ recipe }) => {
    const testedClassName = recipe.tested ? `tested` : ``;
    const tested = <Link to={`/edit/${recipe.id}`} className="link">Edit</Link>
    return (
        <tr>
            <td className={testedClassName}>{recipe.title}</td>
            <td className={testedClassName}>{recipe.ingredients}</td>
            <td className={testedClassName}>{recipe.instructions}</td>
            <td className={testedClassName}>{recipe.dateAdded}</td>
            <td>{tested}</td>
        </tr>
    );
};

Recipe.propTypes = {
    recipe: PropTypes.instanceOf(RecipeModel)
}

export default Recipe;

