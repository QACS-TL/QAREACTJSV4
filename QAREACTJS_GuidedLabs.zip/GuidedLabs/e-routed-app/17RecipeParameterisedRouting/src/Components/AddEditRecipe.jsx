import  { useState, useEffect } from 'react';
import { Navigate, useParams } from 'react-router-dom';
import './css/AddEditRecipe.css';
import RecipeForm from './RecipeForm';
import RecipeModel from './utils/Recipe.model';
import Modal from './utils/Modal';

const AddEditRecipe = ({ submitAction, recipes }) => {

    const [recipe, setRecipe] = useState(null);
    const [submitted, setSubmitted] = useState(false);
    const { id } = useParams();

    useEffect(() => {
        if (id && recipes?.length !== undefined) {
            const recipeToEdit = recipes?.find(currentRecipe => currentRecipe.id == id);
            if (recipeToEdit) {
                setRecipe(recipeToEdit)
            } else {
                setRecipe({ error: `Recipe could not be found` });
            }
        }
        // Add for correct navigation			
        return (() => {

            setRecipe({});
            setSubmitted(false);
      })
  
    }, [id, recipes])

    const submitRecipe = (title, ingredients, instructions, dateAdded, tested, id) => {
        const recipeToSubmit = new RecipeModel(id, title, ingredients, instructions, dateAdded, tested);
        submitAction(recipeToSubmit);
        setSubmitted(true);
    }

    const action = recipe  ? `Edit` : `Add`;

    return (
        <>
            {submitted  && <Navigate to="/" />}
            {recipe?.error && <Modal handleClose={() => setRecipe(null)} message={recipe.error} />}
            <div className="addEditRecipe row">
                <h3>{action} Recipe</h3>
            </div>
            <RecipeForm submitAction={submitRecipe} recipe={recipe} />
        </>
    );
}

export default AddEditRecipe;
