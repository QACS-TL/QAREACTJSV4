import { useState, useEffect } from 'react';
//import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';
import 'popper.js';
import 'jquery';
import './Components/css/qa.css';
import axios from 'axios';
import Header from './Components/Header';
import Footer from './Components/Footer';
import AllRecipes from './Components/AllRecipes';
import AddEditRecipe from './Components/AddEditRecipe';
import Modal from './Components/utils/Modal';

const RECIPESURL = `http://localhost:4000/recipes`;

function App() {
  const [recipes, setRecipes] = useState({});
  const [recipeToEdit, setRecipeToEdit] = useState(null);
  const [onlineStatus, setOnlineStatus] = useState(false);
  const [loading, setLoading] = useState(true);
  const [getError, setGetError] = useState(``);
  const [postError, setPostError] = useState(``);
  const [putError, setPutError] = useState(``);

  useEffect(() => {	
    //setTimeout(() => {
      getRecipes();
    //}, 5000)
  }, []);	
  
  const getRecipes = async () => {
    try {
      const res = await axios.get(RECIPESURL);
      const recipes_from_db = await res.data;
      //console.log(recipes_from_db)
      setRecipes(recipes_from_db);
      setLoading(false);
      setOnlineStatus(true);
    } catch (e) {
      setRecipes(e.message);
      setLoading(false);
      setOnlineStatus(false);
    }	
  };
  
  const postRecipe = async recipe => {
    try {
      await axios.post(RECIPESURL, recipe);	
      setOnlineStatus(true);
      getRecipes();
    } catch (e) {
      setOnlineStatus(false);
    }
  };

  const submitRecipe = recipe => {
    postRecipe(recipe);	
  }
  
  const selectRecipe = recipe => {
    setRecipeToEdit(recipe);
  }

  const updateRecipe = recipe => {
    putRecipe(recipe);
  }

  const putRecipe = async recipe => {
    try {
      setPutError(``);
      await axios.put(`${RECIPESURL}/${recipe.id}`, recipe);
      setOnlineStatus(true);
      getRecipes();
    } catch (e) {
      setPutError(`There was a problem updating the recipe: ${e.message}`);
      setOnlineStatus(false);
    } 
  };

  return (
    <>
      {getError && <Modal handleClose={() => setGetError(``)} message={getError} />}
      {putError && <Modal handleClose={() => setPutError(``)} message={putError} />}
      {postError && <Modal handleClose={() => setPostError(``)} message={postError} />}
      <div className="container">
        <Header />
        <div className="container">
          {!onlineStatus && !loading ? (
            <h3>The data server may be offline, changes will not be saved</h3>
          ) : null}
              <AllRecipes loading={loading}  recipes={recipes} selectRecipe={selectRecipe}/>
              <AddEditRecipe  submitRecipe={submitRecipe} updateRecipe={updateRecipe} recipe={recipeToEdit} />
        </div>
        <Footer />
      </div>
    </>
  );
}

export default App;
