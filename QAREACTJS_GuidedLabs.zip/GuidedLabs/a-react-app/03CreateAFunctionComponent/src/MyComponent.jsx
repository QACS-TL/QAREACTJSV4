import AnotherComponent from './AnotherComponent'; 

const MyComponent = () => {
    return (
        <>
            <h1>Hello World</h1>
            <AnotherComponent /> 
        </>
    );
};

export default MyComponent;
