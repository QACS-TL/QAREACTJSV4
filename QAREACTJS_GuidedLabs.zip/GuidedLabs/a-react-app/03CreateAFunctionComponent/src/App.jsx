import MyComponent from './MyComponent';

function App() {
  return (
    <MyComponent />
  );
}

export default App;
